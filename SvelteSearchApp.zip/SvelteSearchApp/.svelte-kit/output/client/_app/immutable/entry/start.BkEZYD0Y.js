import{a as t}from"../chunks/entry.V7lq5ha_.js";export{t as start};
