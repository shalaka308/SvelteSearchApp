import { c as create_ssr_component, v as validate_component } from "../../../../chunks/ssr.js";
import { g as githubStore, D as DisplayResults } from "../../../../chunks/DisplayResults.js";
const GitHubTab = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let results = [];
  githubStore.subscribe((value) => {
    results = value;
  });
  return `<div class="container"><div class="row d-flex justify-content-center"><div id="GitHub" class="tabcontent swd">${results.length > 0 ? `${validate_component(DisplayResults, "DisplayResults").$$render($$result, { results, source: "GitHub" }, {}, {})}` : `<p data-svelte-h="svelte-6wa1yy">No GitHub results found.</p>`}</div></div></div>`;
});
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${validate_component(GitHubTab, "GitHubTab").$$render($$result, {}, {}, {})}`;
});
export {
  Page as default
};
