import { c as create_ssr_component, v as validate_component } from "../../../../chunks/ssr.js";
import { y as youtubeStore, D as DisplayResults } from "../../../../chunks/DisplayResults.js";
const YouTubeTab = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let results = [];
  youtubeStore.subscribe((value) => {
    results = value;
  });
  return `<div class="container"><div class="row d-flex justify-content-center"><div id="YouTube" class="tabcontent">${results.length > 0 ? `${validate_component(DisplayResults, "DisplayResults").$$render($$result, { results, source: "YouTube" }, {}, {})}` : `<p data-svelte-h="svelte-1s43952">No YouTube results found.</p>`}</div></div></div>`;
});
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${validate_component(YouTubeTab, "YouTubeTab").$$render($$result, {}, {}, {})}`;
});
export {
  Page as default
};
