import { c as create_ssr_component, v as validate_component } from "../../../../chunks/ssr.js";
import { a as googleStore, D as DisplayResults } from "../../../../chunks/DisplayResults.js";
const GoogleTab = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let results = [];
  googleStore.subscribe((value) => {
    results = value;
  });
  return `<div class="container"><div class="row d-flex justify-content-center"><div id="YouTube" class="tabcontent">${results.length > 0 ? `${validate_component(DisplayResults, "DisplayResults").$$render($$result, { results, source: "google" }, {}, {})}` : `<p data-svelte-h="svelte-76akva">No Google results found.</p>`}</div></div></div>`;
});
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${validate_component(GoogleTab, "GoogleTab").$$render($$result, {}, {}, {})}`;
});
export {
  Page as default
};
