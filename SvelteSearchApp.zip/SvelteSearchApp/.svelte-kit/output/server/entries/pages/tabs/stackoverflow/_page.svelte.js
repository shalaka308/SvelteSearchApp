import { c as create_ssr_component, v as validate_component } from "../../../../chunks/ssr.js";
import { s as stackOverflowStore, D as DisplayResults } from "../../../../chunks/DisplayResults.js";
const StackOverFlowTab = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let results = [];
  stackOverflowStore.subscribe((value) => {
    results = value;
  });
  return `<div class="container"><div class="row d-flex justify-content-center"><div id="YouTube" class="tabcontent">${results.length > 0 ? `${validate_component(DisplayResults, "DisplayResults").$$render($$result, { results, source: "google" }, {}, {})}` : `<p data-svelte-h="svelte-6z8zmb">No stackOverflow results found.</p>`}</div></div></div>`;
});
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${validate_component(StackOverFlowTab, "StackOverFlowTab").$$render($$result, {}, {}, {})}`;
});
export {
  Page as default
};
