import { c as create_ssr_component, a as subscribe, e as each, b as add_attribute, d as escape, v as validate_component } from "../../chunks/ssr.js";
import { p as page } from "../../chunks/stores.js";
import { w as writable } from "../../chunks/index.js";
const resultsCountStore = writable({
  github: 0,
  google: 0,
  stackOverflow: 0,
  youtube: 0
});
const Tabs = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$unsubscribe_page;
  $$unsubscribe_page = subscribe(page, (value) => value);
  let counts = {};
  let items = [
    {
      path: "/tabs/github",
      label: "GitHub",
      image: "../images/github.png",
      value: "github"
    },
    {
      path: "/tabs/google",
      label: "Google",
      image: "../images/google.png",
      value: "google"
    },
    {
      path: "/tabs/stackoverflow",
      label: "Stack Overflow",
      image: "../images/stack-overflow.png",
      value: "stackOverflow"
    },
    {
      path: "/tabs/youtube",
      label: "YouTube",
      image: "../images/youtube.png",
      value: "youtube"
    }
  ];
  let activeTab = "/tabs/github";
  let isLoading = {};
  resultsCountStore.subscribe((value) => {
    counts = value;
  });
  $$unsubscribe_page();
  return `<ul class="tabs text-left d-flex">${each(items, (item) => {
    return `<li${add_attribute("class", `${activeTab === item.path ? "active" : ""} tablinks d-flex align-items-center`, 0)}><img${add_attribute("src", item.image, 0)}${add_attribute("alt", item.label, 0)}> <span>${escape(item.label)} <div class="badge">(${escape(counts[item.value] || 0)})</div></span> </li>`;
  })}</ul>  ${isLoading[activeTab] ? `<div class="loader" data-svelte-h="svelte-1xnfpiv"><p>Loading data...</p>  <div class="spinner-border" role="status"><span class="visually-hidden">Loading...</span></div></div>` : ``}`;
});
const css = {
  code: ".loader-wrap.svelte-6cdhv9{position:absolute;width:100%;height:100%;background-color:#ffffffdb;z-index:1}.loader.svelte-6cdhv9{border:16px solid #f3f3f3;border-top:16px solid #9fbb3b;border-radius:50%;width:120px;height:120px;animation:svelte-6cdhv9-spin 2s linear infinite;position:fixed;top:40%;left:45%;transform:translate(-50%, -50%);z-index:1}@keyframes svelte-6cdhv9-spin{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}",
  map: '{"version":3,"file":"Loader.svelte","sources":["Loader.svelte"],"sourcesContent":["<script>\\r\\n        export let isLoading = false;\\r\\n<\/script>\\r\\n\\r\\n{#if isLoading}\\r\\n<div class=\\"loader-wrap\\" id=\\"loader-wrap\\">\\r\\n        <div id=\\"loader\\" class=\\"loader\\"></div>\\r\\n    </div>\\r\\n{/if}\\r\\n\\r\\n\\r\\n<style>\\r\\n\\t.loader-wrap {\\r\\n        position: absolute;\\r\\n        width: 100%;\\r\\n        height: 100%;\\r\\n        background-color: #ffffffdb;\\r\\n        z-index: 1;\\r\\n\\t}\\r\\n        .loader {\\r\\n            border: 16px solid #f3f3f3;\\r\\n            border-top: 16px solid #9fbb3b;\\r\\n            border-radius: 50%;\\r\\n            width: 120px;\\r\\n            height: 120px;\\r\\n            animation: spin 2s linear infinite;\\r\\n            position: fixed;\\r\\n            top: 40%;\\r\\n            left: 45%;\\r\\n            transform: translate(-50%, -50%);\\r\\n            z-index: 1;\\r\\n        }\\r\\n\\r\\n\\r\\n    @keyframes spin {\\r\\n        0% {\\r\\n            transform: rotate(0deg);\\r\\n        }\\r\\n\\r\\n        100% {\\r\\n            transform: rotate(360deg);\\r\\n        }\\r\\n    }\\r\\n</style>"],"names":[],"mappings":"AAYC,0BAAa,CACN,QAAQ,CAAE,QAAQ,CAClB,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,IAAI,CACZ,gBAAgB,CAAE,SAAS,CAC3B,OAAO,CAAE,CAChB,CACO,qBAAQ,CACJ,MAAM,CAAE,IAAI,CAAC,KAAK,CAAC,OAAO,CAC1B,UAAU,CAAE,IAAI,CAAC,KAAK,CAAC,OAAO,CAC9B,aAAa,CAAE,GAAG,CAClB,KAAK,CAAE,KAAK,CACZ,MAAM,CAAE,KAAK,CACb,SAAS,CAAE,kBAAI,CAAC,EAAE,CAAC,MAAM,CAAC,QAAQ,CAClC,QAAQ,CAAE,KAAK,CACf,GAAG,CAAE,GAAG,CACR,IAAI,CAAE,GAAG,CACT,SAAS,CAAE,UAAU,IAAI,CAAC,CAAC,IAAI,CAAC,CAChC,OAAO,CAAE,CACb,CAGJ,WAAW,kBAAK,CACZ,EAAG,CACC,SAAS,CAAE,OAAO,IAAI,CAC1B,CAEA,IAAK,CACD,SAAS,CAAE,OAAO,MAAM,CAC5B,CACJ"}'
};
const Loader = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { isLoading = false } = $$props;
  if ($$props.isLoading === void 0 && $$bindings.isLoading && isLoading !== void 0) $$bindings.isLoading(isLoading);
  $$result.css.add(css);
  return `${isLoading ? `<div class="loader-wrap svelte-6cdhv9" id="loader-wrap" data-svelte-h="svelte-nvbhdj"><div id="loader" class="loader svelte-6cdhv9"></div></div>` : ``}`;
});
const Search = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$unsubscribe_page;
  $$unsubscribe_page = subscribe(page, (value) => value);
  let query = "";
  let isLoading = false;
  $$unsubscribe_page();
  return `<div class="search mb-5"><input id="search-input" class="search-input" type="text" placeholder="Enter a search query"${add_attribute("value", query, 0)}>  <button class="btn" id="btn-search"><img class="search-icon" src="/images/search.png" alt="Search Button"> ${validate_component(Loader, "Loader").$$render($$result, { isLoading }, {}, {})}</button></div>`;
});
const Layout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${$$result.head += `<!-- HEAD_svelte-13edy9i_START --><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">${$$result.title = `<title>Search App</title>`, ""}<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"><script src="https://code.jquery.com/jquery-3.3.1.js" data-svelte-h="svelte-ll616i"><\/script><script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous" data-svelte-h="svelte-l6hk36"><\/script><!-- HEAD_svelte-13edy9i_END -->`, ""} <div class="container"><div class="row d-flex justify-content-center"><div class="col-12 text-center"><div class="logo m-5 position-relative"><img src="/images/logo.png" alt="logo" class="mb-5"> <div class="text-center mb-5">${validate_component(Search, "Search").$$render($$result, {}, {}, {})} ${validate_component(Tabs, "Tabs").$$render($$result, {}, {}, {})}</div></div></div></div></div> ${slots.default ? slots.default({}) : ``}  <hr class="mt-5"> <p class="copyright text-center" data-svelte-h="svelte-1099q7w">© Copyright CCI</p>`;
});
export {
  Layout as default
};
