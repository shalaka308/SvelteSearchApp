

export const index = 6;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/tabs/youtube/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/6.DuLfEZ2V.js","_app/immutable/chunks/scheduler.Dw93JyHj.js","_app/immutable/chunks/index.DK5u_g3J.js","_app/immutable/chunks/resultsStore.CtfSC9CK.js","_app/immutable/chunks/index.oX31WzpR.js","_app/immutable/chunks/DisplayResults.DIME9Usc.js"];
export const stylesheets = [];
export const fonts = [];
