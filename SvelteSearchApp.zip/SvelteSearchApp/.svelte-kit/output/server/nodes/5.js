

export const index = 5;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/tabs/stackoverflow/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/5.Dmrp21gH.js","_app/immutable/chunks/scheduler.Dw93JyHj.js","_app/immutable/chunks/index.DK5u_g3J.js","_app/immutable/chunks/resultsStore.CtfSC9CK.js","_app/immutable/chunks/index.oX31WzpR.js","_app/immutable/chunks/DisplayResults.DIME9Usc.js"];
export const stylesheets = [];
export const fonts = [];
