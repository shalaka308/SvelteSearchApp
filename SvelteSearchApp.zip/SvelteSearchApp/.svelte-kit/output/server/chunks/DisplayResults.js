import { w as writable } from "./index.js";
import { c as create_ssr_component, d as escape, e as each, b as add_attribute } from "./ssr.js";
const githubStore = writable([]);
const googleStore = writable([]);
const stackOverflowStore = writable([]);
const youtubeStore = writable([]);
const DisplayResults = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { results = [] } = $$props;
  let { source = "" } = $$props;
  if ($$props.results === void 0 && $$bindings.results && results !== void 0) $$bindings.results(results);
  if ($$props.source === void 0 && $$bindings.source && source !== void 0) $$bindings.source(source);
  return `${!results || results.length == 0 ? `<p>No results found for ${escape(source)}.</p>` : `<ul class="ul-list">${each(results, (result) => {
    return `<li><div class="d-flex">${result.thumbnail ? `<div class="flex-shrink-0"><img${add_attribute("src", result.thumbnail, 0)} alt="Thumbnail"> </div>` : ``} <div class="flex-grow-1 ms-3"><a${add_attribute("href", result.link, 0)} target="_blank">${escape(result.title)}</a> ${result.description ? `<div class="snippet"><span>${escape(result.description.substring(0, 100))}...</span> </div>` : ``} </div></div> </li>`;
  })}</ul>`}`;
});
export {
  DisplayResults as D,
  googleStore as a,
  githubStore as g,
  stackOverflowStore as s,
  youtubeStore as y
};
